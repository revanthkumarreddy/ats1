Create a database with the name "electronix " 
import the db.sql file located at database/db.sql
if you set a password for your localhost database then change the database properties in includes/db.php
now, run project

admin username is-- electronixadmin
password is-- 12345678

THANKS.

The World is Fake.